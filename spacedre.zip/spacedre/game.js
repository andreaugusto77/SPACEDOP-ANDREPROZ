class Player {
    constructor(x, y, width, height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.speed = 5;
        this.bullets = []; // Armazena os tiros disparados pelo jogador.
    }

    draw(context) {
        context.fillStyle = 'lime';
        context.fillRect(this.x, this.y, this.width, this.height);

        // Desenha todos os tiros disparados pelo jogador
        for (let bullet of this.bullets) {
            bullet.draw(context);
        }
    }

    move(direction) {
        if (direction === 'left' && this.x > 0) {
            this.x -= this.speed;
        } else if (direction === 'right' && this.x + this.width < 800) {
            this.x += this.speed;
        }
    }

    shoot() {
        // Cria um novo tiro (Bullet) e adiciona à lista de tiros do jogador.
        const bullet = new Bullet(this.x + this.width / 2, this.y, 5, 10);
        this.bullets.push(bullet);
    }

    updateBullets() {
        // Atualiza a posição de cada tiro e remove os que saírem da tela.
        this.bullets = this.bullets.filter(bullet => bullet.y > 0);
        for (let bullet of this.bullets) {
            bullet.move();
        }
    }
}

// Classe Bullet (Tiro) - responsável pelos tiros do jogador.
class Bullet {
    constructor(x, y, width, height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.speed = 7;
    }

    draw(context) {
        context.fillStyle = 'yellow';
        context.fillRect(this.x, this.y, this.width, this.height);
    }

    move() {
        this.y -= this.speed; // Move o tiro para cima.
    }
}

// Classe Enemy (Inimigo) - responsável pelos inimigos.
class Enemy {
    constructor(x, y, width, height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.speed = 1;
    }

    draw(context) {
        context.fillStyle = 'red';
        context.fillRect(this.x, this.y, this.width, this.height);
    }

    move() {
        this.y += this.speed; // Move o inimigo para baixo.
    }
}

// Classe Game (Jogo) - controla o estado e fluxo do jogo.
class Game {
    constructor(canvas) {
        this.canvas = canvas;
        this.context = canvas.getContext('2d');
        this.player = new Player(375, 550, 50, 20);
        this.enemies = [];
        this.isGameOver = false; // Adicionado para controlar o estado de vitória.
        this.addEnemies();
        this.bindControls();
    }

    addEnemies() {
        // Adiciona uma matriz de inimigos.
        for (let i = 0; i < 5; i++) {
            for (let j = 0; j < 3; j++) {
                this.enemies.push(new Enemy(i * 100 + 50, j * 50 + 30, 40, 20));
            }
        }
    }

    bindControls() {
        // Vincula os controles do teclado.
        window.addEventListener('keydown', (event) => {
            if (event.key === 'ArrowLeft') {
                this.player.move('left');
            } else if (event.key === 'ArrowRight') {
                this.player.move('right');
            } else if (event.key === ' ') { // Pressiona a barra de espaço para atirar.
                this.player.shoot();
            }
        });
    }

    detectCollisions() {
        // Verifica colisões entre tiros e inimigos.
        for (let bullet of this.player.bullets) {
            for (let i = this.enemies.length - 1; i >= 0; i--) {
                let enemy = this.enemies[i];
                if (
                    bullet.x < enemy.x + enemy.width &&
                    bullet.x + bullet.width > enemy.x &&
                    bullet.y < enemy.y + enemy.height &&
                    bullet.y + bullet.height > enemy.y
                ) {
                    // Remove o inimigo e o tiro quando colidem.
                    this.enemies.splice(i, 1); // Remove o inimigo da lista.
                    bullet.y = -10; // Remove o tiro da tela.
                }
            }
        }
    }

    checkWinCondition() {
        // Verifica se todos os inimigos foram destruídos.
        if (this.enemies.length === 0) {
            this.isGameOver = true;
            alert("You Win!");
        }
    }

    update() {
        // Limpa o canvas antes de redesenhar tudo.
        this.context.clearRect(0, 0, this.canvas.width, this.canvas.height);

        // Atualiza e desenha o jogador e seus tiros.
        this.player.draw(this.context);
        this.player.updateBullets();

        // Atualiza e desenha os inimigos.
        for (let enemy of this.enemies) {
            enemy.move();
            enemy.draw(this.context);

            // Verifica se o inimigo alcançou o limite inferior.
            if (enemy.y + enemy.height >= this.canvas.height) {
                alert("Game Over");
                document.location.reload();
            }
        }

        // Detecta colisões entre tiros e inimigos.
        this.detectCollisions();

        // Verifica se o jogador destruiu todos os inimigos.
        this.checkWinCondition();
    }

    start() {
        // Função gameLoop (loop principal do jogo).
        const gameLoop = () => {
            if (!this.isGameOver) { // Só continua se o jogo não terminou.
                this.update();
                requestAnimationFrame(gameLoop);
            }
        };
        gameLoop();
    }
}

// Inicializa o jogo.
const canvas = document.getElementById('gameCanvas');
canvas.width = 800;
canvas.height = 600;
const game = new Game(canvas);
game.start();
